local app=require("apps.map_planets")
app.run()
