OPEN SPACE CONTROL v0.3.0

ГЛАВНОЕ ИЗМЕНЕНИЕ:
Теперь приложение строит КОМПЛЕКТНУЮ карту SolarSystem из NTM-Space 1.12.2-0.9.2.
В исходнике SolarSystem.java этой версии перечислены 32 тела:
kerbol, moho, eve, gilly, kerbin, mun, minmus, duna, ike, dres, jool,
laythe, vall, tylo, bop, pol, sarnus, hale, ovok, eeloo, slate, tekto,
urlum, polta, priax, wal, tal, neidon, thatmo, nissee, plock, karen.

Числовые характеристики берутся через ntm_stardar.getPlanetStats(name).
Список тел не выдумывается Lua-скриптом: это roster из реального SolarSystem.java.

ВАЖНО:
В Space 0.9.2 getSatellites() содержит ранний return внутри цикла и поэтому
возвращает максимум ПЕРВЫЙ спутник. Поэтому карта НЕ использует этот метод
для перечисления всей системы; она получает parent каждого тела через
getPlanetStats и восстанавливает дерево.

КОМАНДЫ:
  space          - полноценный 3D solar-system экран
  map_planets    - печать и сохранение полной карты в /data/system_map.dat
  osc_inspect    - диагностика OC

УСТАНОВКА:
  lua install.lua

После установки:
  space

Проверка полной карты:
  map_planets
