local fs=require("filesystem")
local shell=require("shell")
local source=fs.canonical(shell.getWorkingDirectory())
local target="/home/osc"
local files={
  "apps/space.lua","apps/map_planets.lua","apps/inspector.lua",
  "lib/renderer3d.lua","lib/camera.lua","lib/vector3.lua","lib/matrix3.lua","lib/math3d.lua",
  "drivers/hbmspace.lua","drivers/solar_system.lua","config/settings.lua","map_planets.lua","README_RU.txt"
}
local function copy(rel)
  local src=fs.concat(source,rel)
  local dst=fs.concat(target,rel)
  assert(fs.exists(src),"missing source: "..src)
  fs.makeDirectory(fs.path(dst))
  if fs.exists(dst) then fs.remove(dst) end
  assert(fs.copy(src,dst))
end
assert(fs.exists(source.."/apps/space.lua"),"Run update.lua from the extracted osc package directory.")
fs.makeDirectory(target)
for _,rel in ipairs(files) do copy(rel) end

-- Convenience command for the complete system map.
fs.makeDirectory("/bin")
local f=io.open("/bin/map_planets","w")
f:write('package.path="/home/osc/?.lua;/home/osc/?/init.lua;"..package.path\nlocal app=require("apps.map_planets")\napp.run()\n')
f:close()

print("Open Space Control updated in "..target)
print("Added complete 32-body SolarSystem roster and getPlanetStats map.")
print("Run: space")
print("Full map: map_planets")
