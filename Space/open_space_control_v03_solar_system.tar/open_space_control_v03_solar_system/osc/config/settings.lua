local M = {}

M.app_name = "OPEN SPACE CONTROL"
M.version = "0.3.0"
M.target_resolution = {160, 50}
M.render_fps = 10
M.telemetry_hz = 2
M.default_planet = "kerbin"
M.debug = false

return M
