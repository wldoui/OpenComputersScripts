local component=require("component")
local computer=require("computer")
local event=require("event")
local term=require("term")
local Settings=require("config.settings")
local Camera=require("lib.camera")
local Renderer=require("lib.renderer3d")
local HBM=require("drivers.hbmspace")
local Solar=require("drivers.solar_system")

local M={}

local function clamp(v,a,b) return math.max(a,math.min(b,v)) end
local function hash(s)
  local h=0
  for i=1,#s do h=(h*31+s:byte(i))%360 end
  return h
end

local function drawHeader(gpu,w,title)
  gpu.setBackground(0x111111); gpu.setForeground(0x66FFAA); gpu.fill(1,1,w,1," ")
  gpu.set(2,1,title); gpu.setForeground(0xAAAAAA); gpu.set(w-17,1,"SPACE CONTROL")
end
local function drawFooter(gpu,w,h,text)
  gpu.setForeground(0x777777); gpu.fill(1,h,w,1," "); gpu.set(2,h,text)
end
local function panel(gpu,x,y,w,h,title)
  gpu.setForeground(0x333333); gpu.fill(x,y,w,h," "); gpu.setForeground(0x66FFAA)
  gpu.set(x,y,"+"..string.rep("-",math.max(0,w-2)).."+")
  for yy=y+1,y+h-2 do gpu.set(x,yy,"|"); gpu.set(x+w-1,yy,"|") end
  gpu.set(x,y+h-1,"+"..string.rep("-",math.max(0,w-2)).."+")
  gpu.set(x+2,y,title)
end

local function orbitalPoint(body, system, t, layer)
  if not body.parent then return 0,0,0 end
  local a=math.max(1,body.semiMajorAxisKm or 1)
  local theta=(t/(body.orbitalPeriod and math.max(body.orbitalPeriod,0.01) or 1))*6.283185307 + math.rad(hash(body.name))
  local e=0
  local r=a*(1-e*e)/(1+e*math.cos(theta))
  local inc=math.rad((hash(body.name)*37)%22-11)
  local x=r*math.cos(theta)
  local z=r*math.sin(theta)
  local y=z*math.sin(inc)
  z=z*math.cos(inc)
  local px,py,pz=orbitalPoint(system.bodies[body.parent],system,t,layer+1)
  return px+x,py+y,pz+z
end

local function logScale(a)
  return math.log(a+1)/math.log(130000000+1)
end

function M.run()
  local gpu=component.gpu
  if not gpu then error("GPU required") end
  local w,h=gpu.getResolution()
  local hbm=HBM.new()
  local system=Solar.new(hbm); system:load()
  local cam=Camera.new(); cam.position.z=7
  local renderer=Renderer.new(gpu)
  local selected=hbm:currentPlanet() or "kerbin"
  local spin=0
  local running=true
  local showNames=true

  while running do
    local t=computer.uptime()
    local current=hbm:currentPlanet()
    local stats=system.bodies[selected]
    gpu.setBackground(0x03070A); gpu.fill(1,1,w,h," ")
    drawHeader(gpu,w,"OPEN SPACE CONTROL // 3D SOLAR SYSTEM")
    local vw=math.floor(w*0.76); panel(gpu,2,3,vw,h-6,"3D COSMOS")
    panel(gpu,vw+3,3,w-vw-5,h-6,"TELEMETRY")

    local vx,vy=3,4; local viewW=vw-2; local viewH=h-8
    local cx=math.floor(vx+viewW/2); local cy=math.floor(vy+viewH/2)

    -- Stars / orbit rings / bodies. The distance compression is logarithmic so
    -- the inner Kerbin system and outer Sarnus/Urlum/Neidon systems fit together.
    for _,name in ipairs(Solar.BODIES) do
      local b=system.bodies[name]
      if b and b.parent then
        local parent=system.bodies[b.parent]
        if parent then
          local radius=logScale(b.semiMajorAxisKm or 1)*math.min(viewW,viewH)*0.46
          if radius>2 then
            local prev=nil
            for i=0,72 do
              local a=i/72*math.pi*2
              local qx=cx+math.floor(radius*math.cos(a))
              local qy=cy+math.floor(radius*0.52*math.sin(a))
              if prev then renderer:line(prev[1],prev[2],qx,qy,".") end
              prev={qx,qy}
            end
          end
        end
      end
    end

    gpu.setForeground(0xFFFF55); gpu.set(cx,cy,"*")
    if showNames then gpu.set(cx+2,cy,"KERBOL") end

    for _,name in ipairs(Solar.BODIES) do
      local b=system.bodies[name]
      if b and name~="kerbol" and b.parent then
        local x,y,z=orbitalPoint(b,system,t,0)
        local radius=math.max(1,logScale(b.semiMajorAxisKm or 1)*math.min(viewW,viewH)*0.46)
        local theta=math.atan2(y,x)
        local sx=cx+math.floor(radius*math.cos(theta))
        local sy=cy+math.floor(radius*0.52*math.sin(theta))
        local ch=(name==selected) and "@" or ((b.landable and "o") or ".")
        gpu.setForeground(name==selected and 0xFFFFFF or 0x66FFAA)
        if sx>=vx and sx<vx+viewW and sy>=vy and sy<vy+viewH then
          gpu.set(sx,sy,ch)
          if showNames and (name==selected or b.parent==selected) then gpu.set(sx+1,sy,name) end
        end
      end
    end

    local tx=vw+6; local y=5
    gpu.setForeground(0x66FFAA); gpu.set(tx,y,"HBM SPACE"); y=y+1
    gpu.setForeground(0xFFFFFF); gpu.set(tx,y,string.sub(hbm.address or "N/A",1,18)); y=y+2
    gpu.setForeground(0x66FFAA); gpu.set(tx,y,"CURRENT"); y=y+1
    gpu.setForeground(0xFFFFFF); gpu.set(tx,y,tostring(current or "N/A")); y=y+2
    gpu.setForeground(0x66FFAA); gpu.set(tx,y,"SELECTED"); y=y+1
    gpu.setForeground(0xFFFFFF); gpu.set(tx,y,selected); y=y+2

    if stats then
      local rows={{"parent",stats.parent},{"radius",stats.radiusKm},{"gravity",stats.surfaceGravity},{"mass",stats.massKg},{"axis",stats.semiMajorAxisKm},{"orbit",stats.orbitalPeriod},{"landable",stats.landable}}
      gpu.setForeground(0x66FFAA); gpu.set(tx,y,"PLANET STATS"); y=y+1
      for _,r in ipairs(rows) do
        if y<h-3 then
          gpu.setForeground(0xAAAAAA); gpu.set(tx,y,string.sub(r[1],1,8))
          gpu.setForeground(0xFFFFFF); gpu.set(tx+9,y,string.sub(tostring(r[2]),1,16)); y=y+1
        end
      end
    end
    y=y+1; gpu.setForeground(0x66FFAA); gpu.set(tx,y,"SYSTEM"); y=y+1
    gpu.setForeground(0xFFFFFF); gpu.set(tx,y,string.format("%d bodies",#Solar.BODIES)); y=y+1
    gpu.setForeground(0xAAAAAA); gpu.set(tx,y,"N=toggle names"); y=y+1
    gpu.set(tx,y,"P=select body")

    drawFooter(gpu,w,h,"LMB select | drag orbit | wheel zoom | Q/E zoom | N names | P body | R reset | ESC exit")

    local wait=math.max(0,1/Settings.render_fps-(computer.uptime()-t))
    local ev={event.pull(wait)}
    if ev[1]=="key_down" then
      local code,char=ev[4],ev[3]
      if code==1 then running=false
      elseif char==113 or char==81 then cam:dolly(-1)
      elseif char==101 or char==69 then cam:dolly(1)
      elseif char==114 or char==82 then cam=Camera.new()
      elseif char==110 or char==78 then showNames=not showNames
      elseif char==112 or char==80 then
        term.clear(); io.write("BODY NAME> "); local name=io.read()
        if name and system.bodies[string.lower(name)] then selected=string.lower(name) end
      end
    elseif ev[1]=="mouse_drag" and ev[3]==1 then
      if ev[4] and ev[5] then cam:rotate(0.02,0.01) end
    elseif ev[1]=="scroll" then
      cam:dolly(-(ev[5] or 0)*0.8)
    end
    spin=spin+0.01
  end
end

return M
