local component=require("component")
local serialization=require("serialization")
local filesystem=require("filesystem")
local HBM=require("drivers.hbmspace")
local Solar=require("drivers.solar_system")

local M={}

function M.run()
  local hbm=HBM.new()
  if not hbm:available() then print("No ntm_stardar component."); return end
  local system=Solar.new(hbm)
  system:load()

  print("=== HBM SPACE / COMPLETE SOLAR SYSTEM ===")
  print("Bodies in Space 0.9.2 source: "..#Solar.BODIES)
  print("")

  for _,name in ipairs(Solar.BODIES) do
    local b=system.bodies[name]
    if b then
      print(string.format("%-8s parent=%-8s r=%-8s a=%-12s g=%-10s land=%s",
        b.name, tostring(b.parent or "-"), tostring(b.radiusKm or "-"),
        tostring(b.semiMajorAxisKm or "-"), tostring(b.surfaceGravity or "-"),
        tostring(b.landable)))
    elseif system.errors[name] then
      print(string.format("%-8s [API ERROR: %s]",name,tostring(system.errors[name])))
    end
  end

  filesystem.makeDirectory("/data")
  local f=io.open("/data/system_map.dat","w")
  if f then
    f:write(serialization.serialize({
      source="NTM-Space 1.12.2-0.9.2 SolarSystem",
      start=hbm:currentPlanet(),
      bodies=system.bodies,
      children=system.children,
      errors=system.errors,
      roster=Solar.BODIES
    }))
    f:close()
    print("")
    print("Saved /data/system_map.dat")
  end
end

return M
