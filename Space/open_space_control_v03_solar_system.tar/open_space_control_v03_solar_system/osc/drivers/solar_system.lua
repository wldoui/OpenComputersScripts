-- Real body roster from NTM-Space 1.12.2-0.9.2 SolarSystem.java.
-- getBodies() is not exposed by ntm_stardar, so this roster is used only to
-- enumerate the bodies that actually exist in this Space build. All numeric
-- telemetry is still fetched from ntm_stardar:getPlanetStats().
local M = {}
M.__index = M

M.BODIES = {
  "kerbol", "moho", "eve", "gilly", "kerbin", "mun", "minmus",
  "duna", "ike", "dres", "jool", "laythe", "vall", "tylo", "bop", "pol",
  "sarnus", "hale", "ovok", "eeloo", "slate", "tekto", "urlum", "polta",
  "priax", "wal", "tal", "neidon", "thatmo", "nissee", "plock", "karen"
}

function M.new(hbm)
  return setmetatable({hbm=hbm, bodies={}, errors={}}, M)
end

function M:load()
  self.bodies={}; self.errors={}
  -- kerbol cannot be returned through getPlanetStats() in this version because
  -- getOrbitalPeriod() assumes a non-nil parent. Keep it as the real root.
  self.bodies.kerbol={
    name="kerbol", parent=nil, star="kerbol", landable=false,
    radiusKm=261600, massKg=1.757e28, semiMajorAxisKm=0,
    surfaceGravity=1712.5, axialTilt=0, sunPower=1,
    orbitalPeriod=0, rotationalPeriod=432000, processingLevel=0,
    isStar=true
  }

  for _,name in ipairs(M.BODIES) do
    if name ~= "kerbol" then
      local stats,err=self.hbm:planetStats(name)
      if stats then
        self.bodies[name]=stats
      else
        self.errors[name]=err or "lookup failed"
      end
    end
  end

  -- Parent links from getPlanetStats are authoritative. This also fixes the
  -- getSatellites() implementation bug in Space 0.9.2, which returns after the
  -- first child instead of returning the whole list.
  self.children={}
  for name,body in pairs(self.bodies) do
    if body.parent then
      self.children[body.parent]=self.children[body.parent] or {}
      table.insert(self.children[body.parent],name)
    end
  end
  for _,list in pairs(self.children) do table.sort(list) end
  return self.bodies
end

function M:all()
  local out={}
  for _,name in ipairs(M.BODIES) do
    if self.bodies[name] then out[#out+1]=self.bodies[name] end
  end
  return out
end

function M:root()
  return self.bodies.kerbol
end

return M
