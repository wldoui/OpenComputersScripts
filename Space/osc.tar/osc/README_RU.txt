OPEN SPACE CONTROL — HOTFIX v0.1.2

Исправлены два падения:

1) lib/renderer3d.lua
   drawOrbit() больше не индексирует число как таблицу. Camera:project()
   возвращает x,y,depth, поэтому координаты сохраняются отдельно.
   Также исправлен аналогичный баг в drawCubePlanet(): точки projection
   теперь обрабатываются как {x,y,depth}.

2) apps/inspector.lua
   добавлен:
       local computer=require("computer")
   поэтому computer.pullSignal() больше не вызывает nil error.

Дополнительно исправлен touch-вызов Camera:project() в apps/space.lua.

УСТАНОВКА НА УЖЕ УСТАНОВЛЕННУЮ СИСТЕМУ:

1. Распакуй содержимое архива в любую папку OpenOS.
2. Перейди в неё:
       cd /home/oc_space_control/osc
3. Запусти:
       lua install.lua

Установщик обновит /boot.lua, /space.lua, /apps, /drivers, /lib,
/system, /config и /docs.

После этого:
       space

Проверка HBM:
       osc_inspect

Ожидаемый компонент:
       ntm_stardar

Если хочешь обновить без вопросов и у тебя архив распакован в
/home/oc_space_control/osc:
       cd /home/oc_space_control/osc
       lua install.lua

Не нужно удалять старую установку перед hotfix.
