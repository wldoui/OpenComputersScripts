local fs=require("filesystem")
local shell=require("shell")
local source=fs.canonical(shell.getWorkingDirectory())
local target="/home/osc"
local files={
  "apps/space.lua",
  "apps/inspector.lua",
  "lib/renderer3d.lua",
  "lib/camera.lua",
  "lib/vector3.lua",
  "lib/matrix3.lua",
  "lib/math3d.lua",
  "drivers/hbmspace.lua",
  "config/settings.lua"
}
local function copy(rel)
  local src=fs.concat(source,rel)
  local dst=fs.concat(target,rel)
  local dir=fs.path(dst)
  fs.makeDirectory(dir)
  assert(fs.exists(src),"missing source: "..src)
  if fs.exists(dst) then fs.remove(dst) end
  assert(fs.copy(src,dst))
end
assert(fs.exists(source.."/apps/space.lua"),"Run update.lua from the extracted osc package directory.")
fs.makeDirectory(target)
for _,rel in ipairs(files) do copy(rel) end
print("Open Space Control updated in "..target)
print("Fixes: Lua syntax, gpu.setForeground boolean argument, 3D projection/orbit, inspector computer module.")
print("Run: space")
