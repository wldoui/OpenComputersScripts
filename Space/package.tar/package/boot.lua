local ROOT = "/home/oc_space_control/osc"
package.path = ROOT .. "/?.lua;" .. ROOT .. "/?/init.lua;" .. package.path

local component = require("component")
local computer = require("computer")
local term = require("term")
local event = require("event")

local function pause()
  term.write("\nPress any key...")
  while true do
    local e = {event.pull()}
    if e[1] == "key_down" or e[1] == "touch" then return end
  end
end

local function runSpace()
  local ok, err = xpcall(function() require("apps.space").run() end, debug.traceback)
  if not ok then term.clear(); print("SPACE CONTROL CRASHED:"); print(err); pause() end
end

local function runInspector()
  local ok, err = xpcall(function() require("apps.inspector").run() end, debug.traceback)
  if not ok then term.clear(); print("INSPECTOR CRASHED:"); print(err); pause() end
end

while true do
  term.clear()
  print("+----------------------------------------------------------------+")
  print("|                    OPEN SPACE CONTROL                          |")
  print("+----------------------------------------------------------------+")
  print("| 1 SPACE  2 INSPECTOR  3 COMPONENTS  4 TERMINAL  5 REBOOT     |")
  print("| 6 SHUTDOWN  Q QUIT                                             |")
  print("+----------------------------------------------------------------+")
  print("Star Dar: " .. (component.isAvailable("ntm_stardar") and "ONLINE" or "OFFLINE"))
  io.write("SELECT> ")
  local c = io.read()
  if c == "1" then
    runSpace()
  elseif c == "2" then
    runInspector()
  elseif c == "3" then
    term.clear()
    print("COMPONENTS")
    for address, typ in component.list() do print(address .. "  " .. typ) end
    pause()
  elseif c == "4" then
    term.clear(); print("Terminal: type commands in the normal shell after exiting OSC."); pause()
  elseif c == "5" then computer.shutdown(true)
  elseif c == "6" then computer.shutdown(false)
  elseif c == "q" or c == "Q" then return end
end
