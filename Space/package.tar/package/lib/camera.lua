local V=require("lib.vector3"); local Mat=require("lib.matrix3")
local C={}; C.__index=C
function C.new() return setmetatable({position=V.new(0,0,12),rx=-0.12,ry=0.25,rz=0,fov=70},C) end
function C:rotate(dx,dy) self.ry=self.ry+dx; self.rx=math.max(-1.45,math.min(1.45,self.rx+dy)) end
function C:dolly(a) self.position.z=math.max(4,math.min(80,self.position.z+a)) end
function C:project(p,cx,cy,scale)
 local q=p:sub(self.position); q=Mat.apply(Mat.rotationXYZ(-self.rx,-self.ry,-self.rz),q)
 if q.z>=-0.1 then return nil end
 local f=scale/math.tan(math.rad(self.fov)*0.5); return cx+(q.x/-q.z)*f,cy-(q.y/-q.z)*f*0.52,-q.z
end
return C
