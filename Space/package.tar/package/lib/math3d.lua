local M={}
function M.clamp(x,a,b) return x<a and a or (x>b and b or x) end
function M.round(x) return x>=0 and math.floor(x+0.5) or math.ceil(x-0.5) end
return M
