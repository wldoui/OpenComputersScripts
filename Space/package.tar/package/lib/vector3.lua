local V={}; V.__index=V
function V.new(x,y,z) return setmetatable({x=x or 0,y=y or 0,z=z or 0},V) end
function V:add(b) return V.new(self.x+b.x,self.y+b.y,self.z+b.z) end
function V:sub(b) return V.new(self.x-b.x,self.y-b.y,self.z-b.z) end
function V:mul(s) return V.new(self.x*s,self.y*s,self.z*s) end
function V:dot(b) return self.x*b.x+self.y*b.y+self.z*b.z end
function V:length() return math.sqrt(self:dot(self)) end
function V:normalize() local l=self:length(); return l==0 and V.new() or self:mul(1/l) end
return V
