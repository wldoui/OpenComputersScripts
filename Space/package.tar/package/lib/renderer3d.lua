local V=require("lib.vector3"); local Math=require("lib.math3d")
local R={}; R.__index=R
function R.new(gpu) return setmetatable({gpu=gpu},R) end
function R:pixel(x,y,ch) x=Math.round(x); y=Math.round(y); if x>=1 and y>=1 then self.gpu.set(x,y,ch) end end
function R:line(x1,y1,x2,y2,ch)
 x1=Math.round(x1); y1=Math.round(y1); x2=Math.round(x2); y2=Math.round(y2)
 local dx=math.abs(x2-x1); local dy=math.abs(y2-y1); local sx=x1<x2 and 1 or -1; local sy=y1<y2 and 1 or -1; local err=dx-dy
 while true do self:pixel(x1,y1,ch or "*"); if x1==x2 and y1==y2 then break end; local e2=2*err; if e2>-dy then err=err-dy;x1=x1+sx end; if e2<dx then err=err+dx;y1=y1+sy end end
end
function R:project(p,camera,cx,cy,scale) return camera:project(p,cx,cy,scale) end
function R:drawStars(cx,cy,w,h,count,seed)
 local x=seed or 17
 for i=1,count do x=(x*1103515245+12345)%2147483647; local px=1+(x%math.max(1,w-2)); x=(x*1103515245+12345)%2147483647; local py=2+(x%math.max(1,h-3)); self:pixel(px,py,(i%7==0) and "+" or ".") end
end
function R:drawSphere(camera,cx,cy,scale,radius,spin)
 local samples=math.max(6,math.floor(radius*2.2)); local pts={}
 for iy=-samples,samples do
  local yy=iy/samples
  local rr=math.sqrt(math.max(0,1-yy*yy))
  for ix=-samples,samples do
   local xx=ix/samples
   if math.abs(xx)<=1 then
    local zz=math.sqrt(math.max(0,1-xx*xx-yy*yy))
    local x=xx*radius; local y=yy*radius; local z=zz*radius
    local rx=x*math.cos(spin)-z*math.sin(spin); local rz=x*math.sin(spin)+z*math.cos(spin)
    local sx,sy,depth=self:project(V.new(rx,y,rz),camera,cx,cy,scale)
    if sx and depth then pts[#pts+1]={sx,sy,depth,xx,yy,zz} end
   end
  end
 end
 table.sort(pts,function(a,b) return a[3]>b[3] end)
 local chars=" .:-=+*#%@"
 for _,p in ipairs(pts) do
  local light=0.5+0.5*(p[5]*0.4+p[4]*0.35+p[6]*0.75)
  local idx=Math.clamp(math.floor(light*(#chars-1))+1,1,#chars)
  self:pixel(p[1],p[2],chars:sub(idx,idx))
 end
end
function R:drawOrbit(camera,cx,cy,scale,radius,tilt,segments)
 local prev=nil
 for i=0,segments do
  local a=i/segments*math.pi*2; local x=math.cos(a)*radius; local z=math.sin(a)*radius
  local y=math.sin(a)*radius*tilt; local q=self:project(V.new(x,y,z),camera,cx,cy,scale)
  if q and prev then self:line(prev[1],prev[2],q[1],q[2],".") end
  if q then prev={q[1],q[2]} else prev=nil end
 end
end
return R
