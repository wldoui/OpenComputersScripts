local component = require("component")
local fs = require("filesystem")
local shell = require("shell")

local args = shell.parse(...)
local source = args[1]
local TARGET = "/home/oc_space_control/osc"

if not source or source == "--autorun" then
  source = shell.getWorkingDirectory()
end
source = fs.canonical(source)

local function die(msg)
  io.stderr:write("OSC INSTALL ERROR: " .. tostring(msg) .. "\n")
  return false
end

local function copyTree(src, dst)
  if fs.isDirectory(src) then
    fs.makeDirectory(dst)
    for name in fs.list(src) do
      local clean = name:gsub("/$", "")
      copyTree(fs.concat(src, clean), fs.concat(dst, clean))
    end
  else
    fs.makeDirectory(fs.path(dst))
    assert(fs.copy(src, dst), "copy failed: " .. src)
  end
end

if not fs.exists(source) then return die("source not found: " .. source) end

fs.makeDirectory(TARGET)
for _, name in ipairs({"apps","drivers","lib","system","config","docs"}) do
  local src = fs.concat(source, name)
  if fs.exists(src) then copyTree(src, fs.concat(TARGET, name)) end
end
for _, name in ipairs({"boot.lua","space.lua","osc_inspect.lua"}) do
  local src = fs.concat(source, name)
  if fs.exists(src) then fs.copy(src, fs.concat(TARGET, name)) end
end

fs.makeDirectory("/bin")
local function write(path, text)
  local f, err = io.open(path, "w")
  if not f then error(err) end
  f:write(text)
  f:close()
end

write("/bin/space", [[
local root = "/home/oc_space_control/osc"
package.path = root .. "/?.lua;" .. root .. "/?/init.lua;" .. package.path
local ok, err = xpcall(function() require("apps.space").run() end, debug.traceback)
if not ok then
  io.stderr:write("OPEN SPACE CONTROL ERROR:\n" .. tostring(err) .. "\n")
end
]])

write("/bin/osc_inspect", [[
local root = "/home/oc_space_control/osc"
package.path = root .. "/?.lua;" .. root .. "/?/init.lua;" .. package.path
local ok, err = xpcall(function() require("apps.inspector").run() end, debug.traceback)
if not ok then io.stderr:write("OSC INSPECTOR ERROR:\n" .. tostring(err) .. "\n") end
]])

write("/bin/osc", [[
local root = "/home/oc_space_control/osc"
package.path = root .. "/?.lua;" .. root .. "/?/init.lua;" .. package.path
local ok, err = xpcall(function() dofile(root .. "/boot.lua") end, debug.traceback)
if not ok then io.stderr:write("OSC ERROR:\n" .. tostring(err) .. "\n") end
]])

if args.autorun or args[1] == "--autorun" then
  fs.makeDirectory("/etc/rc.d")
  write("/etc/rc.d/99_open_space_control.lua", [[
local root = "/home/oc_space_control/osc"
package.path = root .. "/?.lua;" .. root .. "/?/init.lua;" .. package.path
pcall(dofile, root .. "/boot.lua")
]])
end

print("Open Space Control installed to " .. TARGET)
print("Run: space")
print("Or:  osc")
if args.autorun or args[1] == "--autorun" then print("Autorun: ENABLED") end
