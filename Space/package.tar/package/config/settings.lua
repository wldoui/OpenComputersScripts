return {
 app_name="OPEN SPACE CONTROL", version="0.2.0", render_fps=12,
 default_planet="Earth", star_count=90
}
