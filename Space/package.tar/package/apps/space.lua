local component=require("component"); local computer=require("computer"); local event=require("event"); local term=require("term")
local Settings=require("config.settings"); local Camera=require("lib.camera"); local Renderer=require("lib.renderer3d"); local HBM=require("drivers.hbmspace")
local M={}
local function text(g,x,y,s) if x>=1 and y>=1 then g.set(x,y,tostring(s)) end end
local function panel(g,x,y,w,h,title)
 g.setForeground(0x555555); g.set(x,y,"+"..string.rep("-",math.max(0,w-2)).."+")
 for yy=y+1,y+h-2 do g.set(x,yy,"|"); g.set(x+w-1,yy,"|") end
 g.set(x,y+h-1,"+"..string.rep("-",math.max(0,w-2)).."+"); g.setForeground(0x66FFAA); text(g,x+2,y,title)
end
function M.run()
 local gpu=component.gpu; if not gpu then error("GPU component missing") end
 local w,h=gpu.getResolution(); local cam=Camera.new(); local r=Renderer.new(gpu); local hbm=HBM.new(); local selected=Settings.default_planet; local spin=0; local lastX,lastY=nil,nil; local padCache={}; local padTimer=0
 while true do
  local frame=computer.uptime(); gpu.setBackground(0x05080A); gpu.setForeground(0xCCCCCC); gpu.fill(1,1,w,h," ")
  local left=math.floor(w*0.68); local right=w-left-2; panel(gpu,1,2,left,h-4,"3D COSMOS"); panel(gpu,left+2,2,right,h-4,"TELEMETRY")
  local current=hbm:currentPlanet(); if current and current~="" then selected=current end
  local stats=hbm:planetStats(selected); local sats=hbm:satellites(selected)
  local cx=math.floor(left/2)+1; local cy=math.floor(h/2); local radius=math.min(10,math.max(5,math.floor((stats and stats.radiusKm or 6371)/1800)))
  r:drawStars(1,3,left-2,h-6,Settings.star_count,math.floor(computer.uptime()*10)%1000)
  r:drawOrbit(cam,cx,cy,1.0,radius+6,0.18,48); r:drawOrbit(cam,cx,cy,1.0,radius+10,-0.28,48); r:drawSphere(cam,cx,cy,1.15,radius,spin)
  gpu.setForeground(0x66FFAA); text(gpu,cx-6,cy+radius+3,"◉ "..tostring(selected))
  local tx=left+4; local y=4; gpu.setForeground(0xFFFFFF); text(gpu,tx,y,"STAR DAR"); y=y+1
  gpu.setForeground(hbm:available() and 0x66FFAA or 0xFF5555); text(gpu,tx,y,hbm:available() and "ONLINE" or "OFFLINE"); y=y+2
  gpu.setForeground(0xAAAAAA); text(gpu,tx,y,"COMPONENT"); y=y+1; text(gpu,tx,y,string.sub(tostring(hbm.address or "N/A"),1,16)); y=y+2
  gpu.setForeground(0x66FFAA); text(gpu,tx,y,"BODY"); y=y+1; gpu.setForeground(0xFFFFFF); text(gpu,tx,y,string.sub(tostring(current or "N/A"),1,20)); y=y+2
  if stats then
   gpu.setForeground(0x66FFAA); text(gpu,tx,y,"PLANET DATA"); y=y+1
   local rows={{"radius",stats.radiusKm},{"gravity",stats.surfaceGravity},{"mass",stats.massKg},{"orbit",stats.orbitalPeriod},{"landable",stats.canLand}}
   for _,row in ipairs(rows) do gpu.setForeground(0xAAAAAA); text(gpu,tx,y,row[1]); gpu.setForeground(0xFFFFFF); text(gpu,tx+9,y,string.sub(tostring(row[2]),1,13)); y=y+1 end
  else gpu.setForeground(0xFFAA55); text(gpu,tx,y,"PLANET DATA: N/A"); y=y+1 end
  y=y+1; gpu.setForeground(0x66FFAA); text(gpu,tx,y,"SATELLITES"); y=y+1
  if sats and #sats>0 then for i=1,math.min(#sats,math.max(1,h-y-8)) do gpu.setForeground(0xFFFFFF); text(gpu,tx,y,string.format("%02d %s",i,tostring(sats[i]))); y=y+1 end else gpu.setForeground(0x777777); text(gpu,tx,y,"NONE / N/A"); y=y+1 end
  if computer.uptime()-padTimer>2 then padCache=hbm:rocketPads(); padTimer=computer.uptime() end
  y=y+1; gpu.setForeground(0x66FFAA); text(gpu,tx,y,"ROCKET PADS"); y=y+1
  if #padCache==0 then gpu.setForeground(0x777777); text(gpu,tx,y,"NONE / NOT CONNECTED") else for i=1,math.min(#padCache,2) do local p=padCache[i]; gpu.setForeground(0xFFFFFF); text(gpu,tx,y,string.format("PAD %02d %s",i,p.canLaunch==true and "READY" or "LOCKED")); y=y+1 end end
  gpu.setForeground(0x777777); text(gpu,2,h-2,"LMB/RMB orbit  WHEEL/Q/E zoom  P body  R reset  ESC exit")
  local dt=computer.uptime()-frame; local ev={event.pull(math.max(0,1/Settings.render_fps-dt))}
  if ev[1]=="key_down" then local char=ev[3]; local code=ev[4]; if code==1 then break elseif char==113 or char==81 then cam:dolly(-1) elseif char==101 or char==69 then cam:dolly(1) elseif char==114 or char==82 then cam=Camera.new() elseif char==112 or char==80 then term.clear(); io.write("BODY NAME> "); local name=io.read(); if name and #name>0 then selected=name end end
  elseif ev[1]=="mouse_drag" then local x,y=ev[4],ev[5]; if lastX then cam:rotate((x-lastX)*0.025,(y-lastY)*0.025) end; lastX,lastY=x,y
  elseif ev[1]=="mouse_up" then lastX,lastY=nil,nil
  elseif ev[1]=="scroll" then cam:dolly(-(ev[5] or 0)*0.8) end
  spin=spin+0.025
 end
end
return M
