local component = require("component")
local computer = require("computer")
local term = require("term")
local event = require("event")

local M = {}
local SAFE = {
  getComponentName=true, getName=true, getLabel=true, getAddress=true,
  getResolution=true, getViewport=true, getDepth=true, getForeground=true,
  getBackground=true, getActiveBuffer=true, buffers=true,
  maxResolution=true, maxDepth=true, totalMemory=true, freeMemory=true,
  getScreen=true, isAvailable=true
}

function M.run()
  term.clear()
  print("OPEN SPACE CONTROL :: API INSPECTOR")
  print("READ ONLY. Mutating methods are NEVER called.")
  print("")
  for addr, typ in component.list() do
    print("DEVICE " .. tostring(typ) .. "  " .. tostring(addr))
    local ok, p = pcall(component.proxy, addr)
    if ok and p then
      local methods = {}
      for k,v in pairs(p) do
        if type(v) == "function" then methods[#methods+1] = k end
      end
      table.sort(methods)
      for _, name in ipairs(methods) do
        print("  " .. name .. (SAFE[name] and " [SAFE]" or " [NOT CALLED]"))
      end
    else
      print("  proxy unavailable: " .. tostring(p))
    end
    print("")
  end
  print("Star Dar available: " .. tostring(component.isAvailable("ntm_stardar")))
  print("Press any key...")
  while true do
    local e = {event.pull()}
    if e[1] == "key_down" or e[1] == "touch" then break end
  end
end
return M
