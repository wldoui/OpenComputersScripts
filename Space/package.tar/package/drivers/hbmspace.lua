local component = require("component")
local M = {}; M.__index = M

function M.new()
  local self = setmetatable({component=nil,address=nil,lastError=nil}, M)
  self:discover(); return self
end
function M:discover()
  self.component=nil; self.address=nil
  for addr in component.list("ntm_stardar", true) do
    local ok, p = pcall(component.proxy, addr)
    if ok and p then self.component=p; self.address=addr; return true end
  end
  self.lastError="ntm_stardar unavailable"; return false
end
function M:available() return self.component ~= nil end
function M:currentPlanet()
  if not self.component then return nil, "UNAVAILABLE" end
  local ok,a = pcall(self.component.getCurrentPlanet)
  if ok then return a end; return nil,a
end
function M:planetStats(name)
  if not self.component then return nil,"UNAVAILABLE" end
  local ok,a,b,c,d,e,f,g,h,i,j,k,l,m,n = pcall(self.component.getPlanetStats, name)
  if not ok then return nil,a end
  if a == nil then return nil,b or "UNKNOWN BODY" end
  return {name=a,parent=b,star=c,tidallyLockedTo=d,axialTilt=e,canLand=f,
    massKg=g,processingLevel=h,radiusKm=i,semiMajorAxisKm=j,sunPower=k,
    surfaceGravity=l,rotationalPeriod=m,orbitalPeriod=n}
end
function M:satellites(name)
  if not self.component then return nil,"UNAVAILABLE" end
  local ok, packed = pcall(function() return {self.component.getSatellites(name)} end)
  if not ok then return nil,packed end
  return packed
end
function M:rocketPads()
  local out={}
  for addr in component.list("ntm_rocket_pad", true) do
    local p=component.proxy(addr); local r={address=addr}
    local ok,v=pcall(p.canLaunch); r.canLaunch=ok and v or nil
    local ok2,v2=pcall(p.getRocketStats); r.stats=ok2 and v2 or nil
    local ok3,v3=pcall(p.getDestination); r.destination=ok3 and v3 or nil
    out[#out+1]=r
  end
  return out
end
return M
