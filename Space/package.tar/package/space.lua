local ROOT = "/home/oc_space_control/osc"
package.path = ROOT .. "/?.lua;" .. ROOT .. "/?/init.lua;" .. package.path
return require("apps.space").run()
