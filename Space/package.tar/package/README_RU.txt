OPEN SPACE CONTROL 0.2.0

ИСПРАВЛЕННЫЙ ПАКЕТ.

Исправлено:
- inspector.lua теперь подключает computer/event;
- убран запуск через shell.execute("space") из boot;
- добавлены /bin/space, /bin/osc, /bin/osc_inspect;
- исправлен package.path для всех модулей;
- установщик ставит проект в /home/oc_space_control/osc;
- исправлены ошибки 3D renderer/line/project;
- исправлена обработка HBM ntm_stardar;
- исправлено имя canLand;
- добавлен настоящий 3D космос: звёзды, сфера планеты, орбитальные кольца, камера;
- никаких мутаций GPU в inspector.

Установка из распакованной директории:
  lua install.lua

С автозапуском:
  lua install.lua --autorun

Запуск:
  space

Меню:
  osc

Инспектор:
  osc_inspect

Если старую версию ставили в /home/oc_space_control/osc, новая версия просто перезапишет её.
